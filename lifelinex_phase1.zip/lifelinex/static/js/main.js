// main.js
// ------------------------------------------------------------------
// Phase 1: this file is intentionally almost empty.
// Right now the landing page is static — no login, no data, nothing
// dynamic yet. We're just wiring it up so the file exists and loads
// correctly, ready for us to add real behavior in later phases
// (e.g. handling the "Get started" button, form submissions, etc.)
// ------------------------------------------------------------------

console.log("LifelineX Phase 1 — landing page loaded.");

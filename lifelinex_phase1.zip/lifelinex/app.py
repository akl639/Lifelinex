# app.py
# ------------------------------------------------------------------
# This is the ENTRY POINT of the LifelineX backend.
#
# WHAT IS FLASK?
# Flask is a lightweight Python web framework. It lets us:
#   1. Run a local web server on our computer
#   2. Define "routes" (URLs) that return web pages or data
#   3. Later connect a database and build a real API
#
# In Phase 1, this file does ONE thing: it serves the landing page
# (templates/index.html) when someone visits http://127.0.0.1:5000/
#
# In later phases, we will add more routes here (or split them into
# separate files) for registration, login, emergency requests, etc.
# ------------------------------------------------------------------

from flask import Flask, render_template

# Create the Flask application.
# __name__ tells Flask where this file lives, so it knows where to
# look for the "templates" and "static" folders.
app = Flask(__name__)


@app.route("/")
def landing_page():
    """
    This function runs whenever someone visits the homepage ("/").
    render_template() looks inside the "templates" folder for the
    given file and sends it to the browser as an HTML page.
    """
    return render_template("index.html")


# This block only runs when you execute "python app.py" directly
# (it does NOT run if this file is imported elsewhere later).
if __name__ == "__main__":
    # debug=True gives us:
    #  - auto-reload when we save a file
    #  - detailed error pages in the browser (helpful for beginners)
    # NEVER use debug=True in a real production deployment.
    app.run(debug=True, port=5000)
